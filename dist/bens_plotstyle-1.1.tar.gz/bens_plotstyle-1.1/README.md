# bens_plotstyle
A pip-installable package to change the default Matplotlib plotting style (colors, font, font size, resolution, etc.)
